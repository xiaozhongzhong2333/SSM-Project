import com.hr.dao.DepartmentDao;
import com.hr.dao.EmployeeDao;
import com.hr.dao.LeaveDao;
import com.hr.dao.OvertimeDao;
import com.hr.entity.Employee;
import com.hr.entity.Leave;
import com.hr.entity.Overtime;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class TestEmployee {
    private static ClassPathXmlApplicationContext context;
    private static EmployeeDao employeeDao;
    private static LeaveDao leaveDao;
    private static DepartmentDao departmentDao;
    private static OvertimeDao overtimeDao;

    @Before
    public void init() {
        context = new ClassPathXmlApplicationContext("/spring/spring-config.xml");
        employeeDao = context.getBean("employeeDao", EmployeeDao.class);
        leaveDao = context.getBean("leaveDao", LeaveDao.class);
        departmentDao = context.getBean("departmentDao", DepartmentDao.class);
        overtimeDao=context.getBean("overtimeDao",OvertimeDao.class);
    }

    @Test
    public void testFindByNumber() {
        Employee employee = employeeDao.findByNumber(1001);
        System.out.println(employee);
    }

    @Test
    public void testFindByName() {
        Employee employee = employeeDao.findByEmployeeName("张璐");
        System.out.println(employee);
    }
    @Test
    public void testFindDepartmentName() {
        String result= employeeDao.findDepartmentName(1010);
        System.out.println(result);
    }
    @Test
    public void testLea() throws ParseException {
        List<Leave> list = leaveDao.findAllLeave();
        List<Leave> list2 =  leaveDao.findYes();
        System.out.println(list);
//        Leave leave = leaveDao.findByEmployeeNumber(1007);
//      System.out.println(leave);

//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
////        Date StartDate = simpleDateFormat.parse("2020-01-05");
////        Date EndDate = simpleDateFormat.parse("2020-01-10");
////        Leave leave = new Leave(null, 1010, 2013, StartDate, EndDate, "5", "老婆生孩子", "事假", "李烨", "未批准", null);
////        System.out.println(leave.getType());
////        int result = leaveDao.insert(leave);
////        System.out.println(result);

    }

    @Test
    public void testDepartment() {
        String result = departmentDao.findByEmployeeNumber(1010);
        System.out.println(result);
    }
    @Test
    public void testOvertime() {
        List<Overtime> LIST=overtimeDao.findAll();
        System.out.println(LIST);
    }
    @After
    public void finish() {
        context.close();
    }
}
