package com.hr.service;

import com.hr.entity.Overtime;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OvertimeService {
    //根据员工编号查看加班信息
    List<Overtime> findByEmployeeNumber(@Param("Number") Integer number);

    //查看所有加班信息
    List<Overtime> findAll();

    //插入加班数据
    int insert(Overtime overtime);
}
