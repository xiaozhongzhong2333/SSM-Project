package com.hr.service;

import com.hr.dao.OvertimeDao;
import com.hr.entity.Overtime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class OvertimeServiceImpl implements OvertimeService {
    @Autowired
    OvertimeDao dao;

    @Override
    public List<Overtime> findByEmployeeNumber(Integer number) {
        List<Overtime> list = dao.findByEmployeeNumber(number);
        return list;
    }

    @Override
    public List<Overtime> findAll() {
        List<Overtime> list = dao.findAll();
        return list;
    }

    @Override
    public int insert(Overtime overtime) {
        int result = dao.insert(overtime);
        return result;
    }
}
