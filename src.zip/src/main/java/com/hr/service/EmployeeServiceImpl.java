package com.hr.service;

import com.hr.dao.EmployeeDao;
import com.hr.entity.Employee;
import com.hr.pojo.Result;
import com.hr.vo.EmployeePositionVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    EmployeeDao employeeDao;

    @Override
    public List<Employee> findAll() {
        List<Employee> list = employeeDao.findAll();
        return list;
    }

    @Override
    public Result checkLogin(Integer employeeNumber, String password) {
        Employee employee = employeeDao.findByNumber(employeeNumber);
        if (employee == null) {
            return null;
        }
        Result result = null;
        if (employee.getPassword().equals(password)) {
            EmployeePositionVO employeePositionVO = employeeDao.findLevel(employeeNumber);
            result = new Result(employeePositionVO.getLevel(), 1, employee);
            return result;
        }
        return null;
    }

    @Override
    public Employee findByEmployeeName(String name) {
        Employee employee = employeeDao.findByEmployeeName(name);
        System.out.println("Service层" + name);
        return employee;
    }

    @Override
    public Employee findByEmployeeNumber(Integer number) {
        Employee employee = employeeDao.findByNumber(number);
        return employee;
    }

    @Override
    public String findDepartmentName(Integer number) {
        String departmentName = employeeDao.findDepartmentName(number);
        return departmentName;
    }

    @Override
    public String findPositionName(Integer number) {
        String positionName = employeeDao.findPositionName(number);
        return positionName;
    }

    @Override
    public String findEmployeeName(Integer number) {
        String name = employeeDao.findEmployeeName(number);
        return name;
    }
}
