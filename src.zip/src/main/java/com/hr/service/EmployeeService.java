package com.hr.service;

import com.hr.entity.Employee;
import com.hr.pojo.Result;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EmployeeService {

    //查找所有
    List<Employee> findAll();

    Result checkLogin(Integer employeeNumber, String password);

    //根据员工名册查询
    Employee findByEmployeeName(String name);

    //根据用户编号查询
    Employee findByEmployeeNumber(Integer number);

    //查找部门名称
    String findDepartmentName(Integer number);

    //查找职位名称
    String findPositionName(Integer number);

    //查找用户名称
    String findEmployeeName(@Param("number") Integer number);
}
