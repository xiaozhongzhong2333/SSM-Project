package com.hr.service;

import com.hr.dao.LeaveDao;
import com.hr.entity.Leave;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveServiceImpl implements LeaveService {
    @Autowired
    LeaveDao leaveDao;

    @Override
    public List<Leave> findAllLeave() {
        List<Leave> list = leaveDao.findAllLeave();
        return list;
    }

    @Override
    public List<Leave> findByEmployeeNumber(Integer number) {
        List<Leave> list = leaveDao.findByEmployeeNumber(number);
        return list;
    }

    @Override
    public Integer insert(Leave leave) {
        Integer result = leaveDao.insert(leave);
        return result;
    }

    @Override
    public List<Leave> findYes() {
        List<Leave> list = leaveDao.findYes();
        return list;
    }
}
