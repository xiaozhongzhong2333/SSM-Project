package com.hr.service;

import com.hr.entity.Department;

import java.util.List;

public interface DepartmentService {
    String findByEmployeeNumber(Integer employeeNumber);

    List<Department> findAll();
}
