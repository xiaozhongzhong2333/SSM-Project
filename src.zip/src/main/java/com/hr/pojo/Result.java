package com.hr.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
public class Result {
    String message;
    Integer status;
    Object object;
}
