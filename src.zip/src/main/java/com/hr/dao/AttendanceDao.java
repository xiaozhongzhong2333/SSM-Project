package com.hr.dao;

import com.hr.entity.Attendance;

public interface AttendanceDao {
    //上班插入员工执勤
    void insertStart(Attendance attendance);

}
