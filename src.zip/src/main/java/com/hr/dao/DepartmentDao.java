package com.hr.dao;

import com.hr.entity.Department;

import java.util.List;

public interface DepartmentDao {

    //根据employeeNumber查找manager
    String findByEmployeeNumber(Integer employeeNumber);

    //查找所有department
    List<Department> findAll();

}
