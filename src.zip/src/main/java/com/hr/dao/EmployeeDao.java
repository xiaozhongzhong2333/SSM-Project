package com.hr.dao;

import com.hr.entity.Employee;
import com.hr.vo.EmployeePositionVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EmployeeDao {

    //查询所有
    List<Employee> findAll();

    //根据员工编号查询员工
    Employee findByNumber(@Param("number") Integer number);

    //登陆成功查询等级
    EmployeePositionVO findLevel(@Param("number") Integer number);

    //根据用户名查询
    Employee findByEmployeeName(@Param("input") String input);

    //查找部门名称
    String findDepartmentName(@Param("number") Integer number);

    //查找职位名称
    String findPositionName(@Param("number") Integer number);

    //查找用户名称
    String findEmployeeName(@Param("number") Integer number);
}
