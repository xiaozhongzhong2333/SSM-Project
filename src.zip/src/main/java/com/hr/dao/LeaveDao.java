package com.hr.dao;

import com.hr.entity.Employee;
import com.hr.entity.Leave;
import com.hr.vo.EmployeeDepartment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface LeaveDao {
    //查看所有员工请假信息
    List<Leave> findAllLeave();

    //根据员工编号
    List<Leave> findByEmployeeNumber(@Param("number") Integer number);

    //插入加班信息
    Integer insert(Leave leave);

    //查看已经批准的请假
    List<Leave> findYes();
}
