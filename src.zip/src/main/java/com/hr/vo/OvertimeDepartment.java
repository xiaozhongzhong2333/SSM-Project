package com.hr.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.util.Date;
@Data
@ToString
@AllArgsConstructor
public class OvertimeDepartment {
    Integer id;
    String DepartmentName;
    String employeeName;
    Date day;
}
