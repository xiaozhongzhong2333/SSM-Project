package com.hr.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
@Data
@ToString
@AllArgsConstructor
public class EmployeeDepartment {
    String employeeName;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    Date startTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    Date endTime;
    String days;
    String reason;
    String type;
    String status;
}
