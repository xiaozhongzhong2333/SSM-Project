package com.hr.controller;

import com.hr.dao.DepartmentDao;
import com.hr.dao.EmployeeDao;
import com.hr.entity.Employee;
import com.hr.entity.Leave;
import com.hr.service.DepartmentService;
import com.hr.service.EmployeeService;
import com.hr.service.LeaveService;
import com.hr.vo.EmployeeDepartment;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import sun.rmi.log.LogInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/leave")
public class LeaveController {
    @Autowired
    LeaveService leaveService;

    @Autowired
    DepartmentService departmentService;

    @Autowired
    EmployeeService employeeService;

    @RequestMapping("/toAdd")
    public String toAdd() {
        System.out.println("请假中转界面");
        return "admin/leave_add";
    }

    @RequestMapping("/add")
    public String add(HttpServletRequest request, HttpSession session, @Param("start") String startTime1, @Param("end") String endTime1,
                      @Param("days") String days, @Param("type") String type, @Param("reason") String reason) throws ParseException {
        Employee employee = (Employee) session.getAttribute("loged");
        Integer employeeNumber = employee.getEmployeeNumber();
        Integer departmentNumber = employee.getDepartmentNumber();
        String manager = departmentService.findByEmployeeNumber(employeeNumber);
        String status = "未批准";
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
        Date startTime=simpleDateFormat.parse(startTime1);
        Date endTime=simpleDateFormat.parse(endTime1);
        Leave leave = new Leave(null, employeeNumber, departmentNumber, startTime, endTime, days, reason, type, manager, status, null);
        int result = leaveService.insert(leave);
        if (result != 0) {
            String employeeName = employee.getName();
            List<Leave> list = leaveService.findByEmployeeNumber(employeeNumber);
            List<EmployeeDepartment> departmentList = new ArrayList<>();
            int i = 0;
            while (departmentList.size() < list.size()) {
                Leave leave1 = list.get(i);
                EmployeeDepartment department = new EmployeeDepartment(employeeName,
                        leave1.getStartTime(),
                        leave1.getEndTime(), leave1.getDays(),
                        leave1.getReason(), leave1.getType(), leave1.getStatus()
                );
                departmentList.add(department);
                i++;
            }
            request.setAttribute("list", departmentList);
            return "admin/leave_list";
        }
        return null;
    }

    @RequestMapping("oneself")
    public String leave(HttpSession session,HttpServletRequest request) {
        Employee employee = (Employee) session.getAttribute("loged");
        Integer employeeNumber = employee.getEmployeeNumber();
        String employeeName = employee.getName();
        List<Leave> list = leaveService.findByEmployeeNumber(employeeNumber);
        List<EmployeeDepartment> departmentList = new ArrayList<>();
        int i = 0;
        while (departmentList.size() < list.size()) {
            Leave leave1 = list.get(i);
            EmployeeDepartment department = new EmployeeDepartment(employeeName,
                    leave1.getStartTime(),
                    leave1.getEndTime(), leave1.getDays(),
                    leave1.getReason(), leave1.getType(), leave1.getStatus()
            );
            departmentList.add(department);
            i++;
        }
        request.setAttribute("list", departmentList);
        return "admin/leave_list";
    }


    @RequestMapping("list")
    public String leaveAll(HttpSession session,HttpServletRequest request) {
        List<Leave> list = leaveService.findAllLeave();
        List<EmployeeDepartment> departmentList = new ArrayList<>();
        int i = 0;
        while (departmentList.size() < list.size()) {
            Leave leave1 = list.get(i);
            EmployeeDepartment department =
                    new EmployeeDepartment(employeeService.findEmployeeName(leave1.getEmployeeNumber()),
                    leave1.getStartTime(),
                    leave1.getEndTime(), leave1.getDays(),
                    leave1.getReason(), leave1.getType(), leave1.getStatus()
            );
            departmentList.add(department);
            i++;
        }
        request.setAttribute("list", departmentList);
        return "admin/leave_list";
    }

    //已批准
    @RequestMapping("yeslist")
    public String yesList(HttpSession session,HttpServletRequest request) {
        List<Leave> list = leaveService.findYes();
        List<EmployeeDepartment> departmentList = new ArrayList<>();
        int i = 0;
        while (departmentList.size() < list.size()) {
            Leave leave1 = list.get(i);
            EmployeeDepartment department =
                    new EmployeeDepartment(employeeService.findEmployeeName(leave1.getEmployeeNumber()),
                            leave1.getStartTime(),
                            leave1.getEndTime(), leave1.getDays(),
                            leave1.getReason(), leave1.getType(), leave1.getStatus()
                    );
            departmentList.add(department);
            i++;
        }
        request.setAttribute("list", departmentList);
        return "admin/leave_yeslist";
    }
}
