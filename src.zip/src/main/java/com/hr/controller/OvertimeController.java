package com.hr.controller;

import com.hr.entity.Department;
import com.hr.entity.Employee;
import com.hr.entity.Overtime;
import com.hr.service.DepartmentService;
import com.hr.service.EmployeeService;
import com.hr.service.OvertimeService;
import com.hr.vo.OvertimeDepartment;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/overtime")
public class OvertimeController {
    @Autowired
    OvertimeService overtimeService;
    @Autowired
    EmployeeService employeeService;
    @Autowired
    DepartmentService departmentService;

    @RequestMapping("/oneself")
    public String oneself(HttpSession session, HttpServletRequest request) {
        Employee employee = (Employee) session.getAttribute("loged");
        Integer employeeNumber = employee.getEmployeeNumber();
        List<Overtime> overtimes = overtimeService.findAll();
        List<OvertimeDepartment> departments = new ArrayList<>();
        int i = 0;
        while (departments.size() < overtimes.size()) {
            Overtime overtime = overtimes.get(i);
            String departmentName = employeeService.findDepartmentName(overtime.getEmployeeNumber());
            String employeeName = employeeService.findEmployeeName(overtime.getEmployeeNumber());
            OvertimeDepartment department = new OvertimeDepartment(null, departmentName, employeeName, overtime.getDay());
            departments.add(department);
            i++;
        }
        request.setAttribute("page", departments);
        return "admin/oneself_overtime";
    }

    //添加加班信息
    @RequestMapping("/toAdd")
    public String toAdd(HttpServletRequest request) {
        List<Department> departments = departmentService.findAll();
        List<Employee> employees = employeeService.findAll();
        request.setAttribute("dList", departments);
        request.setAttribute("eList", employees);
        return "admin/overtime_add";
    }

    //添加加班信息
    @RequestMapping("/add")
    public String add(@Param("departmentNumber") Integer departmentNumber,
                      @Param("employeeNumber") Integer employeeNumber
            , @Param("date") String date, HttpServletRequest request) throws ParseException {
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
        Date date1=simpleDateFormat.parse(date);
        System.out.println("部门编号"+departmentNumber);
        Overtime overtime = new Overtime(null, departmentNumber, employeeNumber, date1, null, null, null);
        int result = overtimeService.insert(overtime);
        System.out.println("插入结果为"+result);
        if (result != 0) {
            return "redirect:/overtime/oneself";
        }
        return null;
    }


}
