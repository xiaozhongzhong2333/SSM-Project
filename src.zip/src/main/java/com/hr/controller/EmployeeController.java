package com.hr.controller;

import com.hr.entity.Employee;
import com.hr.pojo.Result;
import com.hr.service.EmployeeService;
import com.hr.vo.EmployeePositionDepartment;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
    @Autowired
    EmployeeService employeeService;

    @RequestMapping("/login")
    public String showLogin() {
        return "login";
    }

    @RequestMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    @RequestMapping("{path}")
    public String showPage(@PathVariable String path) {
        return path;
    }

    @RequestMapping("/checkLogin")
    public String checkLogin(@Param("employeeNumber") Integer employeeNumber,
                             @Param("password") String password, HttpSession session) {
        Result result = employeeService.checkLogin(employeeNumber, password);
        if (result != null) {
            Employee employee = (Employee) result.getObject();
            session.setAttribute("loged", employee);
            if ("人事部主任".equals(result.getMessage())) {
                return "/admin/index1";
            } else if ("人事部员工".equals(result.getMessage())) {
                return "/admin/index2";
            } else if ("部门主任".equals(result.getMessage())) {
                return "/admin/index3";
            } else {
                return "/admin/index4";
            }
        } else {
            return "redirect:/employee/login";
        }
    }

    @RequestMapping("/search")
    @ResponseBody
    public Employee findByEmployeeName(@Param("input") String input) {
        Employee employee = employeeService.findByEmployeeName(input);
        return employee;
    }

    @RequestMapping("/detail")
    public String detail(@Param("employeeNumber") Integer employeeNumber, HttpServletRequest request) {
        String positionName = employeeService.findPositionName(employeeNumber);
        String departmentName = employeeService.findDepartmentName(employeeNumber);
        Employee employee = employeeService.findByEmployeeNumber(employeeNumber);
        EmployeePositionDepartment employeePositionDepartment = new
                EmployeePositionDepartment(employee.getId(), employee.getEmployeeNumber(),
                employee.getName(), employee.getGender(),
                employee.getBirthday(), employee.getTelephone(),
                employee.getEmail(), employee.getAddress(), employee.getPhoto(),
                employee.getEducation(), departmentName,
                positionName, employee.getInTime(),
                employee.getPassword(), employee.getNotes());
        request.setAttribute("employee", employeePositionDepartment);
        return "admin/employee_detail";
    }

    @RequestMapping("toUpdate")
    public String toUpdate(@Param("employeeNumber") Integer employeeNumber, HttpServletRequest request) {
        return null;
    }
}
