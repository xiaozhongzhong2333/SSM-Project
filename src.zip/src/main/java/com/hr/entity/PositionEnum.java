package com.hr.entity;

public enum PositionEnum {
    部门主任, 部门员工, 人事部主任, 人事部员工
}
