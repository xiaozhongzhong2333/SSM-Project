package com.hr.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
@Data
@ToString
@AllArgsConstructor
public class Leave {
    Integer id;
    Integer employeeNumber;
    Integer departmentNumber;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    Date startTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    Date endTime;
    String days;
    String reason;
    String type;
    String manager;
    String status;
    String notes;
}

