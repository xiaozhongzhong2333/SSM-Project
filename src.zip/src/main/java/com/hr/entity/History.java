package com.hr.entity;

public class History {

}
