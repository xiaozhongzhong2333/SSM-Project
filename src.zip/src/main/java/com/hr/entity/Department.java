package com.hr.entity;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Department {
    Integer id;
    Integer departmentNumber;
    String name;
    String manager;
    String telephone;
    String address;
    String notes;
}
