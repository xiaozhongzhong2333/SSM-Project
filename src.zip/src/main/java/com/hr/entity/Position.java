package com.hr.entity;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Position {
    Integer id;
    Integer positionNumber;
    String name;
    PositionEnum positionEnum;
    String notes;
}
