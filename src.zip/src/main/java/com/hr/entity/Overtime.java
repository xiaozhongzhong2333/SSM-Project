package com.hr.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.sql.Time;
import java.util.Date;

@Data
@ToString
@AllArgsConstructor
public class Overtime {
    Integer id;
    Integer departmentNumber;
    Integer employeeNumber;
    Date day;
    Time startTime;
    Time endTime;
    String notes;
}
